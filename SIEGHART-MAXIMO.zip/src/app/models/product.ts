export class Product {
    productId: number = 0;
    productCategoryId: number = 0;
    name: string = "";
    description: string = "";
    price: number = 0;
}

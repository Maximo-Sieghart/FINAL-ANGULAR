export class LoginCredentials {
    email: string = "";
    password: string = "";
}
